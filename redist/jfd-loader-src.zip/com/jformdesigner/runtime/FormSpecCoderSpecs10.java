/*
 * Copyright (c) 2012 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import com.jgoodies.forms.factories.FormFactory;

/**
 * @author Karl Tauber
 */
class FormSpecCoderSpecs10
{
	static final Object[] columnSpecs = {
		"min",			FormFactory.MIN_COLSPEC,
		"m",			FormFactory.MIN_COLSPEC,
		"pref",			FormFactory.PREF_COLSPEC,
		"p",			FormFactory.PREF_COLSPEC,
		"default",		FormFactory.DEFAULT_COLSPEC,
		"d",			FormFactory.DEFAULT_COLSPEC,
		"glue",			FormFactory.GLUE_COLSPEC,
		"relgap",		FormFactory.RELATED_GAP_COLSPEC,
		"rgap",			FormFactory.RELATED_GAP_COLSPEC,
		"gap",			FormFactory.RELATED_GAP_COLSPEC,
		"unrelgap",		FormFactory.UNRELATED_GAP_COLSPEC,
		"ugap",			FormFactory.UNRELATED_GAP_COLSPEC,
		"labelcompgap",	FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
		"lcgap",		FormFactory.LABEL_COMPONENT_GAP_COLSPEC,
		"button",		FormFactory.BUTTON_COLSPEC,
		"growbutton",	FormFactory.GROWING_BUTTON_COLSPEC,
		"gbutton",		FormFactory.GROWING_BUTTON_COLSPEC,
	};

	static final Object[] rowSpecs = {
		"min",			FormFactory.MIN_ROWSPEC,
		"m",			FormFactory.MIN_ROWSPEC,
		"pref",			FormFactory.PREF_ROWSPEC,
		"p",			FormFactory.PREF_ROWSPEC,
		"default",		FormFactory.DEFAULT_ROWSPEC,
		"d",			FormFactory.DEFAULT_ROWSPEC,
		"glue",			FormFactory.GLUE_ROWSPEC,
		"relgap",		FormFactory.RELATED_GAP_ROWSPEC,
		"rgap",			FormFactory.RELATED_GAP_ROWSPEC,
		"gap",			FormFactory.RELATED_GAP_ROWSPEC,
		"unrelgap",		FormFactory.UNRELATED_GAP_ROWSPEC,
		"ugap",			FormFactory.UNRELATED_GAP_ROWSPEC,
		"labelcompgap",	getFormFactoryField( "LABEL_COMPONENT_GAP_ROWSPEC", FormFactory.NARROW_LINE_GAP_ROWSPEC ),
		"narrowlinegap",FormFactory.NARROW_LINE_GAP_ROWSPEC,
		"nlinegap",		FormFactory.NARROW_LINE_GAP_ROWSPEC,
		"linegap",		FormFactory.LINE_GAP_ROWSPEC,
		"pargap",		FormFactory.PARAGRAPH_GAP_ROWSPEC,
	};

	private static Object getFormFactoryField( String name, Object def ) {
		// use reflection for compatibility with JGoodies Forms 1.3 and earlier
		try {
			return FormFactory.class.getField( name ).get( null );
		} catch( Exception ex ) {
			// fallback
			return def;
		}
	}
}
